import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const history = () => {
  return (
    <View>
      <Text>history</Text>
    </View>
  )
}

export default history

const styles = StyleSheet.create({})