import * as Yup from 'yup';



const vaildationSchema = Yup.object().shape({
    email:Yup.string().required("Email is required")
    .email("Invaild email format")
    ,
    password:Yup.string().required("Email is required")
    .min("password must be at least 6 character long"),
});

export default vaildationSchema