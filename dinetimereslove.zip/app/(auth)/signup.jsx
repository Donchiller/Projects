import { useRouter } from 'expo-router';
import { Formik } from 'formik';
import { Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import * as Yup from 'yup';
import vaildationSchema from '../../utils/authSchema';

const Signup = () => {
  const router = useRouter();

  const handleSignup = (values) => {
    console.log('Signup values:', values);

  };

  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Invalid email').required('Email is required'),
    password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  });

  return (
    <View className="bg-black">
    <SafeAreaView style={{ backgroundColor: "#000000", marginTop:"45" }}>
      <ScrollView contentContainerStyle={{ height: "100%" }}>
        <View className="m-2 flex justify-center items-center">
          <Image source={require("@/assets/images/dinetimelogo.png")} style={{ width: 200, height: 100 }} />
          <Text className="text-lg text-center text-white font-bold mb-10">Let's get you started</Text>


          <View className="w-5/6 self-center">
            <Formik
              initialValues={{ email: "", password: "" }}
              validationSchema={vaildationSchema}
              onSubmit={handleSignup}
            >
              {({ handleChange, handleBlur, handleSubmit, touched, errors, values }) => (
                <View>
                  <Text className="text-[#f49b33] mt-4 mb-2">Email</Text>
                  <TextInput
                    className="h-10 border border-white text-white rounded px-2 mb-2"
                    keyboardType="email-address"
                    onChangeText={handleChange("email")}
                    value={values.email}
                    onBlur={handleBlur("email")}
                    placeholder="Enter your email"
                    placeholderTextColor="#ccc"
                  />
                  {touched.email && errors.email && (
                    <Text className="text-red-500 text-xs mb-2">{errors.email}</Text>
                  )}

                  <Text className="text-[#f49b33] mt-4 mb-2">Password</Text>
                  <TextInput
                    className="h-10 border border-white text-white rounded px-2 mb-2"
                    secureTextEntry
                    onChangeText={handleChange("password")}
                    value={values.password}
                    onBlur={handleBlur("password")}
                    placeholder="Enter your password"
                    placeholderTextColor="#ccc"
                  />
                  {touched.password && errors.password && (
                    <Text className="text-red-500 text-xs mb-2">{errors.password}</Text>
                  )}
                  <TouchableOpacity onPress={handleSubmit} className="p-2 my-2 bg-[#f49b33] rounded-lg text-black mt-10">
                    <Text className="text-lg font-semibold text-center text-black">Sign Up</Text>
                  </TouchableOpacity>


                </View>
              )}
            </Formik>
            
            <View className="flex justify-center items-center">
              <TouchableOpacity
                className="flex flex-row items-center justify-center mt-5 p-2 items-center"
                onPress={() => router.push("/signin")}>
                <Text className="text-white font-semibold">Already a User?</Text>
                <Text className="text-base font-semibold underline text-[#f49b33] " style={{ marginLeft: "10" }}>
                  Sign in
                </Text>
              </TouchableOpacity>
              <Text className="text-center text-base font-semibold mb-4 text-white">
             <View className="border-b-2 border-[#f49b33] p-2 mb-1 w-24"/>  or {" "} 
             <View className="border-b-2 border-[#f49b33] p-2 mb-1 w-24"/>
          </Text>
           <TouchableOpacity
                className="flex flex-row items-center justify-center mb-5 p-2 items-center"
            >
                <Text className="text-white font-semibold">Be a  </Text>
                <Text className="text-base font-semibold underline text-[#f49b33] " style={{ marginLeft: "10" }}>
                  Guest User
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>


        <View className="flex-1">
          <Image source={require("@/assets/images/Frame.png")} className="w-full h-full" resizeMode="contain" />
        </View>

        <StatusBar barStyle={"light-content"} backgroundColor={'#000000'} />
      </ScrollView>
    </SafeAreaView>
    </View>
  );
};

export default Signup;

const styles = StyleSheet.create({});
