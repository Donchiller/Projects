import { collection, doc, setDoc } from "firebase/firestore";
import { slots } from "../store/restaurants";
import { db } from "./firebaseConfig";
const restaurantData= slots;
const uploadData = async ()=>{
    try{
        for(let i=0; i<restaurantData.length; i++){
            const restaurant = restaurantData[i];
            const docref = doc(collection(db,"slots"),`slots_${i+1}`);
             
            await setDoc(docref , restaurant)
        }
        console.log("Data upload");
    }catch(e){
        console.log("Error uploading data",e);
    }
};

export default uploadData;