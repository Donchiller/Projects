import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Testing = () => {
  return (
    <View>
      <Text>Testing</Text>
    </View>
  )
}

export default Testing

const styles = StyleSheet.create({})