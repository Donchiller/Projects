// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC3FFrDlVhFopbcWCOZ4mXBTvrH6FrsAxs",
  authDomain: "dine-time-a1048.firebaseapp.com",
  projectId: "dine-time-a1048",
  storageBucket: "dine-time-a1048.firebasestorage.app",
  messagingSenderId: "829620512384",
  appId: "1:829620512384:web:c8d68e75f7bcc6f1dfa865",
  measurementId: "G-T92TR5YCQ5"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app); 